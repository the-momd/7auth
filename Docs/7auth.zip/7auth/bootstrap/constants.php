<?php

define('SITE_TITLE', '7Auth Project');
define('BASE_URL', 'http://7auth.mg/');
$basePath = __DIR__ . '/../';
define('BASE_PATH', $basePath);
