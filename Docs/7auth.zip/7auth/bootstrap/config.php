<?php

use Kavenegar\KavenegarApi;
$database_config = (object) [
    'host' => 'localhost',
    'user' => 'root',
    'password' => '',
    'dbname' => '7auth',
    'charset' => 'utf8mb4'
];

$api = new KavenegarApi('42454B52496C73764664494E5464505846332B6B6379346C37345139477243574A3056595553656A4D2B453D');
